package com.example.administrator.music;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tbruyelle.rxpermissions2.RxPermissions;

import java.io.File;

public class MainActivity extends AppCompatActivity implements Runnable {

    int flag = 1;            //“开始/暂停”按钮的判断

    private Button btnStart, btnStop, btnNext, btnLast;
    private TextView txtInfo;
    private ListView listView;
    private SeekBar seekBar;
    private Music music;
    private Handler handler;    // 处理改变进度条事件
    int UPDATE = 0x101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStart = findViewById(R.id.btn_star);//注册组件
        btnStop = findViewById(R.id.btn_stop);
        btnLast = findViewById(R.id.btn_last);
        btnNext = findViewById(R.id.btn_next);
        seekBar = findViewById(R.id.sb);
        txtInfo = findViewById(R.id.tv1);

        btnStart.setOnClickListener(this::onClick);//注册监听
        btnStop.setOnClickListener(this::onClick);
        btnLast.setOnClickListener(this::onClick);
        btnNext.setOnClickListener(this::onClick);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {  //进度条监听

            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) { //用于监听SeekBar进度值的改变

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { //用于监听SeekBar开始拖动

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { //用于监听SeekBar停止拖动后的事件
                int progress = seekBar.getProgress(); //当前位置
                int musicMax = music.mediaPlayer.getDuration();//得到该首歌曲最长秒数
                int seekBarMax = seekBar.getMax();// SeekBar最大值
                music.mediaPlayer.seekTo(musicMax * progress / seekBarMax);//跳到该曲该秒
            }
        });

        new RxPermissions(this).request(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE).subscribe((aBoolean) -> {
            if (aBoolean) {     //动态获取权限
                initData();  //初始化数据
            } else {
                showToast("缺少读取存储权限，部分功能无法使用");
            }
        });
    }

    private void initData() {//当获取到权限以后，进行初始化获取内容
        music = new Music();
        initListViewDataAdapter();  //初始化列表
        Thread thread = new Thread(this);// 自动改变进度条的线程

        handler = new Handler() {//实例化一个handler对象
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);//更新UI
                int mMax = music.mediaPlayer.getDuration();//最大秒数
                if (msg.what == UPDATE) {
                    try {
                        seekBar.setProgress(msg.arg1);
                        txtInfo.setText(setPlayInfo(msg.arg2 / 1000, mMax / 1000));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    seekBar.setProgress(0);
                    txtInfo.setText("播放已经停止");
                }
            }
        };
        thread.start();
    }

    private void initListViewDataAdapter() { //初始化列表
        String[] str = new String[music.musicList.size()];
        int i = 0;
        for (String path : music.musicList) {
            File file = new File(path);
            str[i++] = file.getName();
        }
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, str);
        listView = findViewById(R.id.lv1);
        listView.setAdapter(adapter);
    }

    private void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_star://暂停/开始
                if (flag == 1) { //此时player内没有东西，所以执行musicService.play()
                    music.play();
                    flag++;
                } else { //防止重新开始
                    if (!music.mediaPlayer.isPlaying()) {
                        music.goPlay();
                    } else if (music.mediaPlayer.isPlaying()) {
                        music.pause();
                    }
                }
                break;
            case R.id.btn_stop://停止
                music.stop();
                flag = 1;//当点击停止按钮时，flag置为1
                seekBar.setProgress(0);
                txtInfo.setText("播放已经停止");
                break;
            case R.id.btn_last://上一首
                music.last();
                break;
            case R.id.btn_next://下一首
                music.next();
                break;
        }
    }

    @Override
    public void run() {
        int position, mMax, sMax;
        while (!Thread.currentThread().isInterrupted()) {
            if (music.mediaPlayer != null && music.mediaPlayer.isPlaying()) {
                position = music.getCurrentProgress();//得到当前歌曲播放进度(秒)
                mMax = music.mediaPlayer.getDuration();//最大秒数
                sMax = seekBar.getMax();//seekBar最大值，算百分比
                Message m = handler.obtainMessage();//获取一个Message
                m.arg1 = position * sMax / mMax;//seekBar进度条的百分比
                m.arg2 = position;
                m.what = UPDATE;
                handler.sendMessage(m);
                try {
                    Thread.sleep(1000);// 每间隔1秒发送一次更新消息
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }

    }

    private String setPlayInfo(int position, int max) {   //设置当前播放的textview
        String info = "正在播放:  " + music.songName + "\t\t";
        int pMinutes = 0; //分钟数
        while (position >= 60) { //秒数大于60，清零，分钟加一
            pMinutes++;
            position -= 60;
        }
        String now = (pMinutes < 10 ? "0" + pMinutes : pMinutes) + ":" + (position < 10 ? "0" + position : position); //当前时常
        int mMinutes = 0; //分钟数
        while (max >= 60) { //秒数大于60，清零，分钟加一
            mMinutes++;
            max -= 60;
        }
        String all = (mMinutes < 10 ? "0" + mMinutes : mMinutes) + ":" + (max < 10 ? "0" + max : max); //总时常
        return info + now + " / " + all; //显示时间
    }

    private void showToast(String msg) {  //弹窗事件
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) { //菜单项
        getMenuInflater().inflate(R.menu.menu, menu); //添加布局
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) { //menu的事件
        switch (item.getItemId()){
            case R.id.menu_add: //添加按钮操作

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://freemusicarchive.org/genre/Classical/"));
                startActivity(intent);

                /*String Url = "https://freemusicarchive.org/genre/Classical/";
                String filePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/backups/apps/AndroidPlugin_plugin1.apk";
                Download.DownloadFile(Url, filePath);    // 从网络下载文件到本地*/
                break;
            case R.id.menu_edit_cancel:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}


