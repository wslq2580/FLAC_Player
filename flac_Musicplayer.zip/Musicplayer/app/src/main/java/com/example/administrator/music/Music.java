package com.example.administrator.music;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

public class Music {

    public static final String PATH = Environment.getExternalStoragePublicDirectory("qqmusic").toString();// 获取SD卡总目录。
    public List<String> musicList;// 存放找到的所有flac的绝对路径。
    public MediaPlayer mediaPlayer; // 定义多媒体对象
    public int songNum; // 当前播放的歌曲在List中的下标
    public String songName; // 当前播放的歌曲名

    class MusicFilter implements FilenameFilter { //加载MP3文件
        public boolean accept(File dir, String name) {
            return (name.endsWith(".flac"));//返回当前目录所有以.flac结尾的文件
        }
    }

    public Music() {
        super();
        mediaPlayer = new MediaPlayer();    //实例化多媒体对象
        musicList = new ArrayList<>();
        File MUSIC_PATH = new File(PATH,"song");   //获取Music文件的二级目录
            if (!MUSIC_PATH.exists()) {    //如果当前文件夹不存在，则进行创建当前文件夹
                MUSIC_PATH.mkdirs();
            }
            if (MUSIC_PATH.exists()) {      //如果存在
                File[] files = MUSIC_PATH.listFiles(new MusicFilter());
                if (files == null) {      //如果文件为空，结束
                    return;
                }
                int length = files.length;
                if (length > 0) {
                    for (File file : MUSIC_PATH.listFiles(new MusicFilter())) {
                        musicList.add(file.getAbsolutePath());  //获取每个文件的绝对路径
                    }
                }
            }
    }

    public void setPlayName(String dataSource) { //修改获取MP3的名字
        File file = new File(dataSource);//假设为D:\\mm.mp3
        String name = file.getName();//name=mm.mp3
        int index = name.lastIndexOf(".");//找到最后一个.
        songName = name.substring(0, index);//截取为mm
    }

    public void play() { //开始播放
        try {
            mediaPlayer.reset(); //重置多媒体
            String dataSource = musicList.get(songNum);//得到当前播放音乐的路径
            setPlayName(dataSource);//截取歌名
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);// 指定参数为音频文件
            mediaPlayer.setDataSource(dataSource);//为多媒体对象设置播放路径
            mediaPlayer.prepare();//准备播放
            mediaPlayer.start();//开始播放
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer arg0) {
                    next();//如果当前歌曲播放完毕,自动播放下一首.
                }
            });

        } catch (Exception e) {
            Log.v("MusicService", e.getMessage());
        }
    }


    public void goPlay() {//继续播放
        int position = getCurrentProgress();
        mediaPlayer.seekTo(position);//设置当前MediaPlayer的播放位置，单位是毫秒。
        try {
            mediaPlayer.prepare();//准备
        } catch (Exception e) {
            e.printStackTrace();
        }
        mediaPlayer.start();
    }


    public int getCurrentProgress() {   // 获取当前进度
        if (mediaPlayer != null & mediaPlayer.isPlaying()) {
            return mediaPlayer.getCurrentPosition();
        } else if (mediaPlayer != null & (!mediaPlayer.isPlaying())) {
            return mediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    public void next() { //上一首
        songNum = songNum == musicList.size() - 1 ? 0 : songNum + 1;
        play();
    }

    public void last() { //下一首
        songNum = songNum == 0 ? musicList.size() - 1 : songNum - 1;
        play();
    }


    public void pause() { // 暂停播放
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    public void stop() { //停止播放
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.reset();
        }
    }


}


